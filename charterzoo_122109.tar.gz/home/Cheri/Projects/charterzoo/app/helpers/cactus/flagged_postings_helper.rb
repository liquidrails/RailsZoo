module Cactus::FlaggedPostingsHelper
end

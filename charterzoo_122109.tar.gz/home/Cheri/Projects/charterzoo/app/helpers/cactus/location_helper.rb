module Cactus::LocationHelper
end

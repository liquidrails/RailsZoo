class Cactus::SubcategoryController < ApplicationController
end

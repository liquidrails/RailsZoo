class Cactus::LocationController < ApplicationController
end

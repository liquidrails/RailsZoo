module LinkcodesHelper
end

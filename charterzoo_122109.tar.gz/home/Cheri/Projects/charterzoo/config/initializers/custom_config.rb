class ApplicationError < RuntimeError

end

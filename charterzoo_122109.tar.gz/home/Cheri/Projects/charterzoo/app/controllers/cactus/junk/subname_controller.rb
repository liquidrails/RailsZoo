class Cactus::SubnameController < ApplicationController
end

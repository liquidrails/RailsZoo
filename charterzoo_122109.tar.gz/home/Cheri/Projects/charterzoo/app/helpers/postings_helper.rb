module PostingsHelper
end
